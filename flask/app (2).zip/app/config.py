user_price_black_white=3
printer_price_black_white=2.5

user_price_colored=12
printer_price_colored=11